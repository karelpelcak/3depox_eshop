-- Neovim syntax file
-- Language:	Treesitter query
-- Last Change:	2024 Jul 03

-- it's a lisp!
vim.cmd([[runtime! syntax/lisp.vim]])
